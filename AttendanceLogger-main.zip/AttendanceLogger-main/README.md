# AttendanceLogger
A Simple Go program to Log Attendance!

## Technology Stack
- Go

## How to Run
1. Make sure you have go [installed](https://golang.org/doc/install).
2. Clone and navigate to this repository
3. Enter `go run main.go` in your command line
## How do I contribute?
Check out the Contributing Guidelines to learn more!

## Is this beginner friendly?
YES!

## What if I have a problem?
Contact any maintainer or ACM PESUECC team member!

**This is an official repository maintained by ACM PESUECC for Hacktoberfest 2021!**
